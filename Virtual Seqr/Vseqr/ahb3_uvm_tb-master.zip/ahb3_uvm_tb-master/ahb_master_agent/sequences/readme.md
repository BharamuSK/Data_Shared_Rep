master sequences
