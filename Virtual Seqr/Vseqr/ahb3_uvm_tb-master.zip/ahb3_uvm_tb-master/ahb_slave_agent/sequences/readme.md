slave sequences
