reset sequences
